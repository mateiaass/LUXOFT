1. Open the after_the_model_was_trained/InferenceT5.ipynb notebook using jupyer-notebook.
2. Run the cells and enter your input in the last cell.
4. Run the cell and you'll see the predicted text.
4. Good luck !

Thanks !